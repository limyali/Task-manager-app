import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function Setting({ navigation, route }) {
  
  const [name, setName] = useState('Geena Lim');
  const [bio, setBio] = useState('This is my task manager app!');

  const saveChanges = () => {
    console.log(`Name: ${name}, Bio: ${bio}`);

    navigation.navigate('Home', {
      updatedName: name,
      updatedBio: bio,
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.tb}>
        <View style={styles.iconContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('Home')}>
            <Ionicons name="chevron-back-outline" size={24} color="black" />
          </TouchableOpacity>
        </View>
        <View style={styles.titleContainer}>
          <Text style={styles.title}>Settings</Text>
        </View>
        <View style={styles.placeholder} /> 
      </View>
      <View style={styles.contentContainer}>
        <View style={styles.content}>
          <Text style={styles.label}>Name:</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={(text) => setName(text)}
          />
          <Text style={styles.label}>Bio:</Text>
          <TextInput
            style={styles.input}
            value={bio}
            onChangeText={(text) => setBio(text)}
          />
          <TouchableOpacity style={styles.button} onPress={saveChanges}>
            <Text style={styles.buttonText}>Save Changes</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FEF5FD',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tb: {
    width: '100%',
    flexDirection: 'row',
    backgroundColor: '#F5EEF4',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  iconContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 10,
  },
  titleContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center', 
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    paddingTop: 10,
  },
  placeholder: {
    flex: 1, 
  },
  contentContainer: {
    flex: 1,
    width: '80%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    width: '100%',
    alignItems: 'center',
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  button: {
    backgroundColor: '#007AFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
});