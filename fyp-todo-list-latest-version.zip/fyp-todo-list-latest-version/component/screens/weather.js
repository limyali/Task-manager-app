import { Text, View, SafeAreaView, StyleSheet, ImageBackground, Image, TouchableOpacity, TextInput, FlatList } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import React, { useState, useEffect } from 'react';
import * as Location from 'expo-location';
import { FontAwesome5 } from '@expo/vector-icons';

export default function Weather(props) {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = () => {
    if (searchQuery.trim() === '') {
      // Ensure the search query is not empty
      return;
    }

    fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${searchQuery}&appid=5e11f07df1428eb7cc8a310e8cb0b758&units=metric`
    )
      .then((response) => response.json())
      .then((json) => {
        console.log('json', json);
       if (json.cod === 200) {
        props.navigation.navigate('Details', { name: json.name, searchData: json });
        setSearchQuery('');
      } else {
        // Handle search error here if needed
      }
    })
      .catch((error) => {
        console.log('err',error);
      });
  };


  useEffect (() =>{
    (async() =>{
      let {status} = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted'){
        setErrorMsg("Permission denied");
        return;
      }
      
      let loc = await Location.getCurrentPositionAsync({});

      fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${loc.coords.latitude}&lon=${loc.coords.longitude}&appid=5e11f07df1428eb7cc8a310e8cb0b758&units=metric`, {
        method: "POST",
        headers: {
         Accept: 'application/json' ,
         'Content-Type': 'application/json'
        }
      }).then((response)=> response.json())
      .then((json) => {
        console.log('json',json);
        setLocation(json);
      })
      .catch((error) => {
        console.log('err',error);
      });


    })();
  }, []);

  
  //if there is an error
  if (errorMsg !== null){
    return (
    <View style={styles.container}>
      <Text>There's an error: {errorMsg}</Text>
      <StatusBar style="auto"/>
    </View>
    );
  // success
  }else if (location !== null){
    return (
      <View style={styles.container}>
      <ImageBackground
        style={styles.bg}
        source={require('../assets.js/bg.jpg')}
        blurRadius={20}>
           {/* the display temp */}
          <View style={styles.mainCon}>
            <Text style={styles.text}>{location.name}</Text>
            <Image 
              source={{uri:`https://openweathermap.org/img/wn/${location.weather[0].icon}@2x.png`}}
              style={{width:100,height:100}}
            />
            <Text style={styles.text3}>{location.weather[0].description}</Text>
            <Text style={styles.text2}>{location.main.temp}°C</Text>
          </View>
        </ImageBackground>
      </View>
    );
  // waiting
  }else {
    return (
    <View style={styles.container}>
      <Text>Waiting.. </Text>
      <StatusBar style="auto"/>
    </View>
    );
  }  
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  bg: {
    flex: 1,
    paddingHorizontal: "10%",
    paddingVertical: "15%",
  },
  mainCon:{
    flex:1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text:{
    fontSize: 50,
    paddingHorizontal: 20,
    fontWeight: 'bold',
    justifyContent: 'center',
    alignItems: 'center',
    color: "#999999",
  },
  text2:{ 
    fontSize: 60,
    color: "#999999",
    fontWeight: 'bold',
  },
  text3:{
    fontSize: 22,
    color: "#999999",
    fontWeight: 'bold',
  },

  
});