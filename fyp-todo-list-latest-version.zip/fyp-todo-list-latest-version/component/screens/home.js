import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  Modal,
} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import React, { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Section from '../Section';
import TodoList from '../lists';
import AddListModal from '../AddListModal';

export default function Home({ navigation, route }) {
  const [addTodoVisible, setAddTodoVisible] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [sections, setSections] = useState(Section);
  const [lists, setLists] = useState([]);
  const { updatedName, updatedBio } = route.params || {};
  const [displayData, setDisplayData] = useState([]);

  function toggleAddTodoModal() {
    setAddTodoVisible(!addTodoVisible);
  }

  function closeModal() {
    setIsOpen(false);
  }

  const addSection = (newSection) => {
    setSections([...sections, newSection]);
  };

  const renderList = (list) => {
    return <TodoList list={list} updateList={updateList} />;
  };

  const updateList = (list) => {
    setLists((prevLists) =>
      prevLists.map((item) => (item.id === list.id ? list : item))
    );
  };

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    try {
      const savedData = await AsyncStorage.getItem('sectionsData');
      if (savedData) {
        const currentData = JSON.parse(savedData);
        console.log('Retrieved Data current:', currentData);
        console.log('Retrieved Data saved:', savedData);
        setDisplayData(currentData);
      }
    } catch (error) {
      console.log('Retrieved Data err:', error);
    }
  };

  return (
    <SafeAreaView width="100%" height="100%">
      <View style={styles.container}>
        <Modal
          animationType="slide"
          visible={addTodoVisible}
          onRequestClose={() => toggleAddTodoModal()}>
          <AddListModal
            closeModal={toggleAddTodoModal}
            addSection={addSection}
          />
        </Modal>
        <View style={styles.tb}>
          <View style={styles.userInfo}>
            <Text style={styles.p}>{updatedName || 'Geena Lim'}</Text>
            <Text style={styles.p1}>
              {updatedBio || 'This is my task manager app!'}
            </Text>
          </View>
        </View>
        <View style={{ flexDirection: 'row' }}>
          <Text style={styles.title}>TODO LIST</Text>
        </View>
        <View style={{ marginVertical: 48 }}>
          <TouchableOpacity onPress={() => toggleAddTodoModal()}>
            <View style={styles.addWrapper}>
              <AntDesign name="plus" size={16} color="black" />
            </View>
          </TouchableOpacity>
        </View>
        <View style={{ height: 280, paddingLeft: 32 }}>
          <FlatList
            data={sections}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            renderItem={({ item }) => (
              <TodoList list={item} updateList={updateList} />
            )}
            keyboardShouldPersistTaps="always"
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FEF5FD',
    alignItems: 'center',
  },

  tb: {
    width: '100%',
    flexDirection: 'row',
    backgroundColor: '#F5EEF4',
    alignItems: 'center',
    paddingHorizontal: 10,
  },

  p: {
    fontSize: 20,
    padding: 5,
    fontWeight: 'bold',
    color: '#9cadce',
  },

  p1: {
    fontSize: 15,
    padding: 5,
    fontWeight: 'bold',
    flexDirection: 'column',
    color: '#9cadce',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 30,
    color: '#fb6f92',
  },
  addWrapper: {
    width: 60,
    height: 60,
    borderRadius: 60,
    backgroundColor: '#DBDADB',
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#C0C0C0',
    borderWidth: 1,
  },

  userInfo: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
