import {
  StyleSheet,
  View,
  Text,
  KeyboardAvoidingView,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  FlatList,
  Keyboard,
} from 'react-native';
import { AntDesign, Ionicons } from '@expo/vector-icons';
import React, { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function TodoModal({ closeModal, list, updateList }) {
  const [newTodo, setNewTodo] = useState('');
  const [newNote, setNewNote] = useState('');
  const [key, setKey] = useState('');
  const [value, setValue] = useState([]);
  const [displayData, setDisplayData] = useState([]);

  const taskCount = list.todos.length;
  const completedCount = list.todos.filter((todo) => todo.completed).length;

  const renderTodo = (todo, index) => {
    return (
      <View style={styles.todoContainer}>
        <TouchableOpacity onPress={() => toggleTodoCompleted(index)}>
          <Ionicons
            name={todo.completed ? 'ios-square' : 'ios-square-outline'}
            size={24}
            color="grey"
            style={{ width: 32 }}
          />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text
            style={[styles.todo, { color: todo.completed ? 'grey' : 'black' }]}>
            {todo.title}
          </Text>
          {todo.notes && <Text style={styles.note}>{todo.notes}</Text>}
        </View>
        <TouchableOpacity onPress={() => deleteTask(todo.id)}>
          <AntDesign name="delete" size={22} color="red" />
        </TouchableOpacity>
      </View>
    );
  };

  const toggleTodoCompleted = (index) => {
    const updatedTodos = [...list.todos];
    updatedTodos[index].completed = !updatedTodos[index].completed;
    const updatedList = { ...list, todos: updatedTodos };
    updateList(updatedList);
  };

  const addTask = () => {
    const newTask = {
      title: newTodo,
      completed: false,
      notes: newNote || '', 
    };
    storeData([...list.todos, newTask]);
    list.todos.push(newTask);
    updateList(list);
    setNewTodo('');
    setNewNote('');
    Keyboard.dismiss();
  };

  const deleteTask = (taskId) => {
    const updatedTasks = list.todos.filter((task) => task.id !== taskId);
    const updatedList = { ...list, todos: updatedTasks };
    updateList(updatedList);
  };

  useEffect(()=>{
    storeData(list.todos);
    getData();
  }, [])

  const storeData = async (tasks) => {
    try {
      console.log('storeData', tasks)
      await AsyncStorage.setItem(list.name, JSON.stringify([list.name,{todos:tasks}]));
    } catch (error) {
      console.log('storeData err',error);
    }
  };
  // setKey(list.name);
  // setValue([newTodo, newNote]);

  const getData = async () => {
    try {
      const savedData = await AsyncStorage.getItem(list.name);
      if (savedData) {
        const currentData = JSON.parse(savedData);
        setDisplayData(currentData.todos); // Assuming todos is an array
        console.log('getData',currentData);
      }
    } catch (error) {
      console.log('getData err',error);
    }
  }; 

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
      <SafeAreaView style={styles.container}>
        <TouchableOpacity
          style={{ position: 'absolute', top: 64, right: 32, zIndex: 10 }}
          onPress={closeModal}>
          <AntDesign name="close" size={24} color="black" />
        </TouchableOpacity>
        <View
          style={[
            styles.section,
            styles.header,
            { borderBottomColor: list.color },
          ]}>
          <View>
            <Text style={styles.title}>{list.name}</Text>
            <Text style={styles.taskCount}>
              {completedCount} completed out of {taskCount} tasks
            </Text>
          </View>
        </View>

        <View style={[styles.section, { flex: 3 }]}>
          <FlatList
            data={list.todos}
            renderItem={({ item, index }) => renderTodo(item, index)}
            contentContainerStyle={{
              paddingHorizontal: 32,
              paddingVertical: 64,
            }}
            showsHorizontalScrollIndicator={false}
          />
        </View>

        <View style={[styles.section, styles.footer]}>
          <View style={{ flexDirection: 'column', flex: 1 }}>
            <TextInput
              style={[styles.input, { borderColor: list.color }]}
              placeholder="Add a new task"
              onChangeText={(text) => setNewTodo(text)}
              value={newTodo}
              placeholderTextColor="grey"
            />
            <TextInput
              style={[styles.input, { borderColor: list.color }]}
              placeholder="Add a note"
              onChangeText={(text) => setNewNote(text)}
              value={newNote}
              placeholderTextColor="grey"
              multiline={true}
            />
          </View>
          <TouchableOpacity
            style={[styles.addTodo, { backgroundColor: list.color }]}
            onPress={addTask}>
            <AntDesign name="plus" size={24} color="white" />
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  section: {
    flex: 1,
    alignSelf: 'stretch',
  },
  header: {
    justifyContent: 'flex-end',
    marginLeft: 64,
    borderBottomWidth: 3,
  },
  title: {
    fontSize: 30,
    fontWeight: '800',
    color: 'black',
  },
  taskCount: {
    marginTop: 4,
    marginBottom: 16,
    color: 'grey',
    fontWeight: '600',
  },
  footer: {
    paddingHorizontal: 32,
    flexDirection: 'row',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    height: 48,
    width: '100%',
    borderWidth: 2,
    borderRadius: 6,
    marginRight: 8,
    paddingHorizontal: 8,
  },
  addTodo: {
    borderRadius: 4,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  todoContainer: {
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  todo: {
    color: 'black',
    fontWeight: '600',
    fontSize: 16,
  },
  note: {
    color: 'grey',
    fontSize: 14,
    marginTop: 4,
  },
});
