import {
  StyleSheet,
  View,
  Text,
  KeyboardAvoidingView,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import React, { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const backgroundColors = [
  '#e5e0b3',
  '#ffc107',
  '#ff9800',
  '#ff5722',
  '#795548',
  '#607d8b',
  '#9979d2',
];

export default function AddListModal({ closeModal, addSection }) {
  const [name, setName] = useState('');
  const [selectedColor, setSelectedColor] = useState(null);
  const [displayData, setDisplayData] = useState('');

  const renderColors = () => {
    return backgroundColors.map((color) => {
      return (
        <TouchableOpacity
          key={color}
          style={[
            styles.colorSelect,
            {
              backgroundColor: color,
              borderColor: selectedColor === color ? 'black' : 'transparent',
            },
          ]}
          onPress={() => setSelectedColor(color)}
        />
      );
    });
  };

  const addTodo = () => {
    if (name && selectedColor) {
      const newSection = {
        name,
        color: selectedColor,
        todos: [],
      };
      addSection(newSection);
      setDisplayData(name);
      setName('');
      setSelectedColor(null);
      closeModal();
    }
  };

  useEffect(() => {
    storeData();
  }, [displayData]);

  const storeData = async () => {
    try {
      console.log('storeData addlist', displayData)
      await AsyncStorage.setItem('sectionsData', JSON.stringify(displayData));
    } catch (error) {
      console.log('async err', error);
    }
  };


  return (
    <KeyboardAvoidingView style={styles.container} behavior="padidng">
      <TouchableOpacity
        style={{ position: 'absolute', top: 64, right: 32 }}
        onPress={closeModal}>
        <AntDesign name="close" size={24} color="black" />
      </TouchableOpacity>

      <View style={{ alignSelf: 'stretch', marginHorizontal: 32 }}>
        <Text style={styles.title}>Create Todo List</Text>
        <TextInput
          style={styles.input}
          placeholder="Add List Name"
          placeholderTextColor="grey"
          onChangeText={(text) => setName(text)}
        />
        <View style={styles.colorContainer}>{renderColors()}</View>
        <TouchableOpacity
          style={[
            styles.create,
            { backgroundColor: selectedColor ? selectedColor : '#393838' },
          ]}
          onPress={addTodo}>
          <Text style={{ color: 'white', fontWeight: '600' }}>Add!</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: 'black',
    alignSelf: 'center',
    marginBottom: 16,
  },
  input: {
    borderWidth: 2,
    borderColor: '#A9A4A4',
    borderRadius: 6,
    height: 50,
    marginTop: 8,
    paddingHorizontal: 16,
    fontSize: 18,
    color: 'black',
  },
  create: {
    marginTop: 24,
    height: 50,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#393838',
  },
  colorContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  colorSelect: {
    width: 30,
    height: 30,
    borderRadius: 4,
  },
});
