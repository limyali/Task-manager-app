import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

//Screens
import Home from './screens/home';
import Weather from './screens/weather';
import Setting from './screens/Setting';

const Tab = createBottomTabNavigator();

export default function Navigation({ state }) {
  console.log('navigation state',state);
  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: '#F5EEF4' }, 
      }}
    >
      <Tab.Screen
        name="Home"
        component={Home}
        options={{
          title: "",
          tabBarIcon: ({ size, color }) => (
            <MaterialCommunityIcons name="home" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Weather"
        component={Weather}
        options={{
          title: "",
          tabBarIcon: ({ size, color }) => (
            <MaterialCommunityIcons
                name="weather-cloudy"
                size={size}
                color={color}
              />
          ),
        }}
      />
      <Tab.Screen
        name="Setting"
        component={Setting}
        options={{
          title: "",
          tabBarIcon: ({ size, color }) => (
            <MaterialCommunityIcons name="cog" size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}