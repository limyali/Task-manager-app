// in order to add section list, must have data to show

export default Section = [
  {
    id:1,
    name: "Huang Li birthday",
    color: '#f08080',
    todos: [
      {
        title: "Buy treats",
        completed: false,
        notes: '',
      },
      {
        title: "Put up decorations",
        completed: true,
        notes: '',
      },
      {
        title: "Invite dog friends",
        completed: false,
        notes: '',
      },
    ],
    notes: '',
  },
  {
    id:2,
    name: "School works",
    color: '#d4afb9',
    todos: [
      {
        title: "Build a prototype",
        completed: false,
        notes: '',
      },
      {
        title: "write report",
        completed: true,
        notes: '',
      },
      {
        title: "debugging",
        completed: false,
        notes: '',
      },
    ],
    notes: '',
  },
  {
    id:3,
    name: "Weekends", 
    color: '#ffb3c6',
    todos: [
      {
        title: "Visit temple",
        completed: false,
        notes: '',
      },
      {
        title: "Swimming",
        completed: false,
        notes: '',
      },
      {
        title: "change bedsheet",
        completed: false,
        notes: '',
      },
    ],
    notes: '',
  }
];



